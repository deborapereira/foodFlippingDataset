#undef UNICODE

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")
// #pragma comment (lib, "Mswsock.lib")
#include <lsl_cpp.h>

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "27015"

using namespace std;

int __cdecl main(void)
{

	cout << "starting the TCP server. Waiting for a client..." << endl;


	//////   INITIALIZE LSL OUTLET STREAM   ////
	
	const int nchannels = 1;
	lsl::stream_info info("server_stream", "synch", nchannels, lsl::IRREGULAR_RATE, lsl::cf_string, "id23443");

	// make a new outlet
	lsl::stream_outlet outlet(info);

	std::cout << "wait for LSL" << std::endl;
	while (!outlet.wait_for_consumers(1200));
	std::cout << "Conneted to LSL" << std::endl;

	///////////////////////

	WSADATA wsaData;
	int iResult;

	SOCKET ListenSocket = INVALID_SOCKET;
	SOCKET ClientSocket = INVALID_SOCKET;

	struct addrinfo *result = NULL;
	struct addrinfo hints;

	int iSendResult;
	char recvbuf[DEFAULT_BUFLEN];
	int recvbuflen = DEFAULT_BUFLEN;

	// Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed with error: %d\n", iResult);
		return 1;
	}

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;

	// Resolve the server address and port
	iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
	if (iResult != 0) {
		printf("getaddrinfo failed with error: %d\n", iResult);
		WSACleanup();
		return 1;
	}

	// Create a SOCKET for connecting to server
	ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
	if (ListenSocket == INVALID_SOCKET) {
		printf("socket failed with error: %ld\n", WSAGetLastError());
		freeaddrinfo(result);
		WSACleanup();
		return 1;
	}

	// Setup the TCP listening socket
	iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen);
	if (iResult == SOCKET_ERROR) {
		printf("bind failed with error: %d\n", WSAGetLastError());
		freeaddrinfo(result);
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}

	freeaddrinfo(result);

	iResult = listen(ListenSocket, SOMAXCONN);
	if (iResult == SOCKET_ERROR) {
		printf("listen failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}

	// Accept a client socket
	ClientSocket = accept(ListenSocket, NULL, NULL);
	if (ClientSocket == INVALID_SOCKET) {
		printf("accept failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}

	cout << "client accepted" << endl;

	// No longer need server socket
	closesocket(ListenSocket);




	// receive the client request
	iResult = recv(ClientSocket, recvbuf, recvbuflen, 0);

	//////    INFORM LSL 
	std::string sample("request_received");
	outlet.push_sample(&sample);


	// answer the client
	std::string  c_str_send = "tS";
	iSendResult = send(ClientSocket, c_str_send.c_str(), iResult, 0);


	// register sequential timestamps to check speed of LSL:
	sample = "Finish";
	outlet.push_sample(&sample);
	sample = "Finish1";
	outlet.push_sample(&sample);
	sample = "Finish2";
	outlet.push_sample(&sample);


	// shutdown the connection since we're done
	iResult = shutdown(ClientSocket, SD_SEND);

	// cleanup
	closesocket(ClientSocket);
	WSACleanup();

	cout << "SYNCHRONIZATION DONE" << endl;
	cin.get();

	return 0;
}